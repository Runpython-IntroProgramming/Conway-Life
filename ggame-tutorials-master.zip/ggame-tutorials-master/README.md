# ggame-tutorials

## Image credits
* bunny.png: http://www.clker.com/clipart-11353.html
* bunnysheet5.png: Stephen Challener (Redshrike), commissioned by Tebruno99 and hosted by OpenGameArt.org
* explosion1.png: http://gintasdx.deviantart.com/art/Explosion-spritesheet-for-games-347785133
* explosion2.png: https://github.com/apolinario/spriteOnHover
* four_spaceship_by_albertov.png: Spaceships sprites by AlbertoV (dyabitgames.com)
* grass_texture239.jpg: http://picsfair.com/green-grass-background.html
* starfield.jpg: https://www.flickr.com/photos/filterforge/14174682786
* sun.png: NASA
* beach-ball-575425_640.png: https://pixabay.com/static/uploads/photo/2014/12/21/23/28/beach-ball-575425_640.png
* orb-150545_640.png: https://pixabay.com/en/orb-ball-globe-glossy-glow-red-150545/
